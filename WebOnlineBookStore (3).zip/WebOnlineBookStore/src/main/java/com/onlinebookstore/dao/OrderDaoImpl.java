package com.onlinebookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.onlinebookstore.model.Order;
import com.onlinebookstore.utility.ObjectsUtility;

public class OrderDaoImpl implements orderDao {

	Connection con = ObjectsUtility.getDbConnection();

	@Override
	public boolean placeOrder(String customerUserEmail, List<String> bookNames, List<String> bookPrices,
			List<String> liBookQuantity) {

		try {
			con.setAutoCommit(false);
			PreparedStatement ps = con.prepareStatement(
					"insert into orders(orderStatus, bookName, totalBill, customerEmail, quantity) values(?,?,?,?,?)");

			for (int i = 0; i < bookNames.size(); i++) {
				String bookName = bookNames.get(i);
				String bookPrice = bookPrices.get(i);
				String bookQuantity = liBookQuantity.get(i);

				double totalBill = Double.valueOf(bookPrice) * Double.valueOf(bookQuantity);

				ps.setString(1, "Success");
				ps.setString(2, bookName);
				ps.setLong(3, Math.round(totalBill));
				ps.setString(4, customerUserEmail);
				ps.setInt(5, Integer.valueOf(bookQuantity));
				ps.addBatch();

			}

			int[] arr = ps.executeBatch();

			boolean isNotAdded = Arrays.stream(arr).anyMatch(x -> x == 0);
			if (isNotAdded) {
				con.rollback();
			} else {
				boolean isDeleted = clearCart(customerUserEmail);
				if (isDeleted) {
					con.commit();
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public List<Order> getAllOrder(String customerEmail) {
		List<Order> orderList = new ArrayList<Order>();

		try {
			PreparedStatement ps = con.prepareStatement("select * from orders where customerEmail=?");

			ps.setString(1, customerEmail);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Order order = new Order();
				order.setOrderId(rs.getInt("orderId"));
				order.setOrderStatus(rs.getString("orderStatus"));
				order.setTotalBill(rs.getDouble("totalBill"));
				order.setCustomerName(rs.getString("customerEmail"));
				order.setBookName(rs.getString("bookName"));
				order.setQuantity(rs.getInt("quantity"));
				orderList.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return orderList;
	}

	@Override
	public boolean clearCart(String customerUserEmail) {

		try {
			PreparedStatement ps = con.prepareStatement("delete from cart where custEmainId=?");

			ps.setString(1, customerUserEmail);

			int x = ps.executeUpdate();

			if (x != 0) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String checkOrderStatus(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

}
