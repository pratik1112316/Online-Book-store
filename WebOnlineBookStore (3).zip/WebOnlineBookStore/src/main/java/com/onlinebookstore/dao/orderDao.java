package com.onlinebookstore.dao;

import java.util.List;

import com.onlinebookstore.model.Order;

public interface orderDao {

	public boolean placeOrder(String customerEmail, List<String> bookNames, List<String> bookPrices,List<String> liBookQuantity);
	List<Order> getAllOrder(String customerEmail);
	boolean clearCart(String customerUserEmail);
	String checkOrderStatus(int orderId);
}
