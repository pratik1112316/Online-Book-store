package com.onlinebookstore.model;

public class Order {

	private int orderId;
	private String orderStatus;
	private String bookName;
	private double totalBill;
	private String customerName;
	private int quantity;
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getOrderId() {
		return orderId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public double getTotalBill() {
		return totalBill;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public void setTotalBill(double totalBill) {
		this.totalBill = totalBill;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderStatus=" + orderStatus + ", bookName=" + bookName + ", totalBill="
				+ totalBill + ", customerName=" + customerName + ", quantity=" + quantity + "]";
	}

}
