package com.onlinebookstore.utility;

public class Constant {

	public static final String LOGEDINUSER = "logedInUser";
}
