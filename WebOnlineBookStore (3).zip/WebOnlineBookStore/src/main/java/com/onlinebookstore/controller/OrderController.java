package com.onlinebookstore.controller;

import java.io.IOException;
import java.util.List;

import com.onlinebookstore.model.Order;
import com.onlinebookstore.model.Users;
import com.onlinebookstore.service.orderService;
import com.onlinebookstore.utility.Constant;
import com.onlinebookstore.utility.ObjectsUtility;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/OrderController")
public class OrderController extends HttpServlet {

	orderService orderService = ObjectsUtility.getOrderService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String frompage = request.getParameter("frompage");
		
		if(frompage.equalsIgnoreCase("allOrders")) {
			String customerEmail = request.getParameter("custEmailId");
			
			List<Order> orders = orderService.getAllOrder(customerEmail);
			
			request.setAttribute("allOrder", orders);
			RequestDispatcher rd = request.getRequestDispatcher("ShowOrders.jsp");
			rd.forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String frompage = request.getParameter("frompage");
		
		if(frompage.equalsIgnoreCase("fromCart")) {
			
			String bookNames = request.getParameter("bookNames");
			String bookPrices = request.getParameter("bookPrices");
			String[] bookQuantity = request.getParameterValues("bookQuantity");
			
			HttpSession session = request.getSession();
			Users users = (Users) session.getAttribute(Constant.LOGEDINUSER);
			
			boolean isOrderPlace = orderService.placeOrder(users.getUserEmailId(), bookPrices, bookNames, bookQuantity);
			if(isOrderPlace) {
				List<Order> orders = orderService.getAllOrder(users.getUserEmailId());
				
				request.setAttribute("allOrder", orders);
				RequestDispatcher rd = request.getRequestDispatcher("ShowOrders.jsp");
				rd.forward(request, response);
			}
		}

	}
}
