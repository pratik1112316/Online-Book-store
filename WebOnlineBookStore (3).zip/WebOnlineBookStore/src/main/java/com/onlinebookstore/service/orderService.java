package com.onlinebookstore.service;

import java.util.List;

import com.onlinebookstore.model.Order;

public interface orderService {

	boolean placeOrder(String customerEmail,String bookPrice,String bookNames, String[] bookQuantity);
	List<Order> getAllOrder(String customerEmail);
	boolean clearCart(String customerUserEmail);
	String checkOrderStatus(int orderId);
}
