package com.onlinebookstore.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.onlinebookstore.dao.orderDao;
import com.onlinebookstore.model.Order;
import com.onlinebookstore.utility.ObjectsUtility;

public class OrderServiceImpl implements orderService {

	orderDao orderDao = ObjectsUtility.getOrderDao();
	
	@Override
	public boolean placeOrder(String customerUserEmail,String bookPrice,String bookNames, String[] bookQuantity) {
		String[] arrBookNames = bookNames.split(",");
		String[] arrBookPrices = bookPrice.split(",");
		
		List<String> liBookNames = Arrays.stream(arrBookNames)
				.filter(x -> !x.equals("null"))
				.collect(Collectors.toList());
		
		List<String> liBookPrices = Arrays.stream(arrBookPrices)
				.filter(x -> !x.equals("null"))
				.collect(Collectors.toList());
		
		List<String> liBookQuantity = Arrays.stream(bookQuantity)
				.map(OrderServiceImpl::setQuantity)
				.collect(Collectors.toList());
		
		boolean isOrderPlaced = orderDao.placeOrder(customerUserEmail, liBookNames, liBookPrices, liBookQuantity);
		
		if(isOrderPlaced) {
			return true;
		}
		
		return false;
	}
	
	private static String setQuantity(String bookQuanity) {
		if(bookQuanity==null||bookQuanity==" "||bookQuanity=="") {
			return "1";
		}
		return bookQuanity;
	}

	@Override
	public List<Order> getAllOrder(String customerEmail) {
		List<Order> orders = orderDao.getAllOrder(customerEmail);
		return orders;
	}

	@Override
	public boolean clearCart(String customerUserEmail) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String checkOrderStatus(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

}
